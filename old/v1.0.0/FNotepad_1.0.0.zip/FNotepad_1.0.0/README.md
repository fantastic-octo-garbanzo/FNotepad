# FNotepad

Texteditor in Deutsch und Englisch, geschrieben in Java.

Das neuste Release oder `out/artifacts/FNotepad.jar` downloaden und mit
`java -jar FNotepad.jar` ausführen.
