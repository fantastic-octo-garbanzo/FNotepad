# FNotepad Changelog

## FNotepad v1.3.2 (2021-02-13)

### Added
- File extensions
- Cancel button
- Changelogs

### Changed
- Better folder structure
- All releases are now in the release folder
- All files were split in German and English ones


## FNotepad v1.3.1 (2021-02-12)

### Added
- Fullscreen support for both languages
- New file extensions

### Changed
- Fixed language mistakes


## FNotepad v1.2.2 (2021-02-11)

### Changed
- Fix window close bug


## FNotepad v1.2.0 (2021-02-09)

### Added
- Installation programm for Windows
- New windows for new documents

### Changed
- Better language selection
