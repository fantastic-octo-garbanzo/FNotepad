import javax.swing.*;

public class SaveToPdf {
    public void SaveToPdf(JTextArea txtArea, String documentName){

    }
}
