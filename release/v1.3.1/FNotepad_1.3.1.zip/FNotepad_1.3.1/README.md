# FNotepad

## Über / About

### Deutsch

Ein Texteditor in Java geschrieben, verfügbar in Deutsch und Englisch.

Das neuste Release oder `out/artifacts/FNotepad.jar` downloaden und mit `java -jar FNotepad.jar` ausführen.

### English

A texteditor written in Java, availible in German and English.

Download the newest release or `out/artifacts/FNotepad.jar` and run it with `java -jar FNotepad.jar`.



## Contributers

-> See [CONTRIBUTERS.md][1]

[1]: https://github.com/fantastic-octo-garbanzo/FNotepad/blob/main/CONTRIBUTERS.md



#### If you want to help us or you have a bug report, you can open a Issue. Thank you!
